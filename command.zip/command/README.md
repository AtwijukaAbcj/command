# api docs
This repository consists of the payments API. It will be the center for all the integrations in the system
